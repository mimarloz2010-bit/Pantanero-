# Pantanero

Guía de pesca de agua dulce con los embalses de España, mapa, especies y cuaderno de capturas.

Cada vez que subes cambios, GitHub compila el APK automáticamente en la pestaña **Actions**.
