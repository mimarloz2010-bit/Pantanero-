plugins { id("com.android.application") }
android {
    namespace = "es.pantanero.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "es.pantanero.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
